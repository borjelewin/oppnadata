<?php
class CsvItem {
	public $name;
	public $email;
	public $url;
}