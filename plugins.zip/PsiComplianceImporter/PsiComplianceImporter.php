<?php
/*
 * Plugin Name: PSI compliance importer
 * Plugin URI: https://github.com/edelegationen
 * Description: Used internally, imports csv files from import/.
 * Author: Bazooka Ab
 * Author URI: http://www.bazooka.se
 * Version: 1.0
 */

include('lib/CsvItem.php');

add_action('init', 'importData');

function importData() {
	$path = dirname(__file__).'/import/import.csv';
	if(!isset($_REQUEST['import_csv'])) {
		return;
	}

	if(!class_exists(PsiComplianceMonitor)) {
		return;
	}

	if(file_exists($path)) {
		$items = parseCsvFile($path);
		echo 'found ' . count($items);
		foreach($items as $item) {
			$item->url = $item->url;
			if(!AuthorityExists($item->url)) {		
				echo '<br/>';
				echo 'New: ' . $item->name;
				createAuthorityPost($item);
			}
		}
	}
	die();
}

function AuthorityExists($url) {
	$args = array(
		'post_type' => PsiComplianceMonitor::buildFieldId('authority'),
		'posts_per_page' => 1000,
		'orderby' => 'meta_value_num',
		'order' => 'ASC',
		'meta_query' => array(
			array(
				'key' => PsiComplianceMonitor::buildFieldId('url'),
				'value' => $url,
			)
		)
	);
	$query = new WP_Query( $args );

	if ($query->have_posts()) {
		return true;
	};

	return false;
}

function createAuthorityPost($csvItem) {
	global $user_ID;

	$newPost = array(
		'post_title' => $csvItem->name,
		'post_content' => '',
		'post_status' => 'publish',
		'post_date' => date('Y-m-d H:i:s'),
		'post_author' => 1,
		'comment_status' => 'closed',
		'ping_status' => 'closed',
		'post_type' => PsiComplianceMonitor::buildFieldId('authority'),
		'post_category' => array(0)
	);

	$postId = wp_insert_post($newPost);
	
	add_post_meta($postId, PsiComplianceMonitor::buildFieldId('url'),  $csvItem->url);
	add_post_meta($postId, PsiComplianceMonitor::buildFieldId('contact_email'),  $csvItem->email, true);
	add_post_meta($postId, PsiComplianceMonitor::buildFieldId('api_suffix'),  PsiCompliantAuthorityPostType::API_SUFFIX, true);
}

function parseCsvFile($filepath){
	$items = array();
	if (($handle = fopen($filepath, "r")) !== FALSE) {
		while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
			$num = count($data);

			$item = new CsvItem();
			$item->name = ucwords(mb_strtolower($data[0]));
			$item->email = $data[1];

			if (strpos($data[2],'http://') === false){
				$data[2] = 'http://'.$data[2];
			}

			$item->url = $data[2];

			$items[] = $item;
		}
		fclose($handle);
	}

	return $items;
}