<?php
/*
 * Plugin Name: PSI compliance monitor
 * Plugin URI: https://github.com/edelegationen
 * Description: Checks different URLs for PSI compliance
 * Author: Bazooka Ab
 * Author URI: http://www.bazooka.se
 * Version: 1.0
 */

include('lib/PostType/StatusCodesTaxonomy.php');
include('lib/PostType/TaxonomyFilter.php');
include('lib/PostType/StatusCodeFilter.php');
include('lib/PostType/PsiCompliantAuthorityPostType.php');

include('lib/Widget/BaseWidget.php');
include('lib/Widget/WidgetField.php');
include('lib/Widget/PsiWidget.php');

include('lib/PsiCronChecker.php');
include('lib/ResponseHeaders.php');
include('lib/PsiComplianceMonitor.php');
include('lib/APIWrapper.php');

// Set plugin path.
PsiComplianceMonitor::$pluginPath = ABSPATH . PLUGINDIR . '/PsiComplianceMonitor/';

// Setup the plugin.
$t = new PsiComplianceMonitor();

if(isset($_REQUEST['run_pcm_cron'])) {
	add_action('init', array($t, 'cron'));
}

// Register activation / deactivation hooks.
register_activation_hook(PsiComplianceMonitor::$pluginPath . 'PsiComplianceMonitor.php', array('PsiComplianceMonitor', 'activation'));
register_deactivation_hook(PsiComplianceMonitor::$pluginPath . 'PsiComplianceMonitor.php', array('PsiComplianceMonitor', 'deActivation'));