<?php 
class PsiCronChecker {
	private $id;
	private $taxOtherSlug = 'http-code-other';

	/**
	 * Sets up the url checker.
	 */
	public function __construct($postId) {
		$this->id = $postId;
		
		$url = self::addTrailingSlash($this->getUrl()) . $this->getUrlSuffix();
		
		if(!$this->validateUrl($url) || $url == '' || $url == false) {
			error_log("Couldn't validate url " . $url . " on postid " . $postId);
			return;
		}

		$this->setStatusCode($this->getStatusCode($url));
	}

	/**
	 * Adds a trailing slash to an url.
	 *
	 * @param string $url The url to add a trailing slash to.
	 *
	 * @return string
	 */
	public static function addTrailingSlash($url) {
		if (!preg_match("/.*\/$/", $url)) {
			$url = $url . "/";
		}
		
		return $url;
	}

	/**
	 * Removes any old status code term and sets a new one based on the status code.
	 *
	 * @param int $statusCode The status code for the url.
	 *
	 * @return boolean True if it could match the status code in the taxonomy, false if it's marked as "other".
	 */
	private function setStatusCode($statusCode) {
		$this->removeStatusCodes();

		$url = self::addTrailingSlash($this->getUrl()) . $this->getUrlSuffix();

		update_post_meta($this->id, PsiComplianceMonitor::buildFieldId('checked_date'), date('Y-m-d H:i:s', time()));

		if($term = get_term_by('slug','http-code-' . $statusCode, PsiComplianceMonitor::buildFieldId('response'))) {
			wp_set_object_terms($this->id, $term->slug, PsiComplianceMonitor::buildFieldId('response'));
			return true;
		}

		wp_set_object_terms($this->id, $this->taxOtherSlug, PsiComplianceMonitor::buildFieldId('response'));

		return false;
	}

	/**
	 * Removes all relationships to the status code taxonomy,
	 *
	 * @return void.
	 */
	private function removeStatusCodes() {
		wp_delete_object_term_relationships($this->id, PsiComplianceMonitor::buildFieldId('response'));
	}

	/**
	 * Gets the meta data url from the post.
	 *
	 * @return void.
	 */
	private function getUrl() {
		return trim(get_post_meta($this->id, PsiComplianceMonitor::buildFieldId('url'), true));
	}

	/**
	 * Gets the meta data url from the post.
	 *
	 * @return void.
	 */
	private function getUrlSuffix() {
		return trim(get_post_meta($this->id, PsiComplianceMonitor::buildFieldId('api_suffix'), true));
	}

	/**
	 * Checks if an url is valid.
	 *
	 * @param string $url The url to check.
	 *
	 * @return boolean True if valid url.
	 */
	private function validateUrl($url) {
		if(!filter_var($url, FILTER_VALIDATE_URL)){
			return false;
		}

		return true;
	}

	/**
	 * Makes a request and checks the repsonse headers for the status code.
	 *
	 * @param string $url The url to fetch.
	 *
	 * @return int The status code that was returned.
	 */
	private function getStatusCode($url) {
		$header = ResponseHeaders::getResponseHeader($url);

		return (isset($header['http_code']) ? $header['http_code'] : '000');
	}
}