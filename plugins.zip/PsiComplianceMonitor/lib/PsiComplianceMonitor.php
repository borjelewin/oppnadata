<?php
class PsiComplianceMonitor {

	const DOMAIN = 'pcm';
	const CRON_PER_PAGE = 25;
	const USE_API_CACHE = true;

	public static $pluginPath = '';


	/**
	 * Sets up the plugin.
	 */
	public function __construct() {
		new PsiCompliantAuthorityPostType();

		// Filters
		add_filter('cron_schedules', array('PsiComplianceMonitor', 'setCronSchedule'));

		// Actions
		add_action('generate_rewrite_rules', array(&$this, 'addRewriteRules'));
		add_action(self::buildFieldId('cron'),  array(&$this, 'cron'));
		add_action('widgets_init', array(&$this, 'registerWidgets'));
		add_action('wp_ajax_approved-authorities', array(&$this, 'getApprovedAuthorities'));
		add_action('wp_ajax_nopriv_approved-authorities', array(&$this, 'getApprovedAuthorities'));	
		add_action('admin_enqueue_scripts', array(&$this, 'enqueueAdminStyleSheet'));
		add_action('wp_enqueue_scripts', array(&$this, 'enqueueStyleSheet'), 10, 0);

		// Shortcodes
		add_shortcode('psidata', array(&$this, 'renderPsiShortcode'));
		add_shortcode('psi-approved', array(&$this, 'renderPsiApproved'));
		add_shortcode('psi-total', array(&$this, 'renderPsiTotal'));
	}

	/**
	 * Enqueues CSS files to the admin theme.
	 *
	 * @return void.
	 */
	public function enqueueAdminStyleSheet() {
		wp_enqueue_style(PsiComplianceMonitor::buildFieldId('compliance-monitor'), plugins_url('PsiComplianceMonitor/styles/admin.css'));
	}
	/**
	 * Enqueues CSS files to the frontend theme.
	 *
	 * @return void.
	 */
	public function enqueueStyleSheet() {
		wp_enqueue_style(PsiComplianceMonitor::buildFieldId('psi-compliance-monitor'), plugins_url('PsiComplianceMonitor/styles/main.css'), false, '1.0');
	}

	/**
	 * Prints approved authorities as json data.
	 *
	 * @return void.
	 */
	public function getApprovedAuthorities() {
		$wrapper = new APIWrapper(PsiComplianceMonitor::USE_API_CACHE);

		try {			
			$this->addApprovedAuthorities($wrapper, true, 2 * 60);	
		} 
		catch(Exception $ex) {
			$wrapper->message = $ex->getMessage();
		}

		header('Content-Type: application/json');
		echo json_encode($wrapper);

		die();
	}

	/**
	 * If cache is not valid - adds authorities to wrapper object and cache it.
	 *
	 * @return void.
	 */
	private function addApprovedAuthorities(&$wrapper, $useCache, $cacheTimeout) {
		if($wrapper->validCache()) {
			return;
		}

		$authorities = $this->getAllAuthorities();
		$this->filterAuthoritiesByStatus($authorities, PsiCompliantAuthorityPostType::AUTHORITY_STATUS_APPROVED);
		$this->convertAuthoritiesToCustomArray($authorities);
		$wrapper = $this->addItemsToWrapperObject($authorities);

		if($useCache) {
			set_transient(APIWrapper::CACHE_KEY, json_encode($wrapper->items), $cacheTimeout);
		}
	}

	/**
	 * Adds custom rewrite rules outside of wordpress.
	 * (The .htaccess file needs to be writable by the webserver and
	 * pretty urls need to be activated.)
	 *
	 * @return void.
	 */
	public function addRewriteRules() {
		error_log('added rules');
		global $wp_rewrite;
		$rewriteRules = array(
			/* JSON v1 API */
			'api/v1/([^/]+)?$' => 'wp-admin/admin-ajax.php?action=$1', // without trailing slash
			'api/v1/([^/]+)/?$' => 'wp-admin/admin-ajax.php?action=$1' // with trailing slash
		);

		$wp_rewrite->non_wp_rules = $rewriteRules + $wp_rewrite->non_wp_rules;
	}

	/**
	 * Registers widgets.
	 *
	 * @return void.
	 */
	public function registerWidgets() {
		register_widget( 'PsiWidget' );
	}

	/**
	 * Renders the PSI data table.
	 *
	 * @param array $atts The attributes for the shortcode
	 *
	 * @return string The rendered table
	 */
	public function renderPsiShortcode($atts) {
		extract( shortcode_atts( array(
			'type' => '7',
		), $atts));

		return PsiWidget::render($type);
	}

	/**
	 * Returns the total number of approved PSI authorities,
	 *
	 * @param array $atts The attributes for the shortcode
	 *
	 * @return int The number of authorities.
	 */
	public function renderPsiApproved($atts) {
		$authorities = get_posts(array(
			'post_type' => PsiComplianceMonitor::buildFieldId(PsiCompliantAuthorityPostType::POST_TYPE),
			'post_status' => 'any',
			'posts_per_page' => '-1',
			'orderby' => 'title',
			'order'=> 'ASC',
		));
		
		$total = 0;

		foreach($authorities as $authority) {
			$status = PsiCompliantAuthorityPostType::getAuthorityStatus($authority->ID);
			if($status == PsiCompliantAuthorityPostType::AUTHORITY_STATUS_APPROVED) {
				$total++;
			}
		}

		return $total;
	}

	/**
	 * Returns the total number of PSI authorities,
	 *
	 * @param array $atts The attributes for the shortcode
	 *
	 * @return int The number of authorities.
	 */
	public function renderPsiTotal($atts) {
		return count(get_posts(array(
			'post_type' => PsiComplianceMonitor::buildFieldId(PsiCompliantAuthorityPostType::POST_TYPE),
			'post_status' => 'any',
			'posts_per_page' => '-1',
			'orderby' => 'title',
			'order'=> 'ASC',
		)));
	}

	/**
	 * Adds a cutom cron schedule for wp-cron.
	 *
	 * @param array $schedules The array containing all the schedules for wp.
	 *
	 * @return array The array containing all the schedules for wp.
	 */
	public function setCronSchedule($schedules) {
	 	$schedules[self::buildFieldId('schedule')] = array(
	 		'interval' => HOUR_IN_SECONDS / 2,
	 		'display' => __( 'Custom schedule for PCM plugin' )
	 	);
	 	return $schedules;
	}

	/**
	 * Runs on activation of the plugin.
	 *
	 * @return void.
	 */
	public static function activation() {
		wp_schedule_event(time(), self::buildFieldId('schedule'), self::buildFieldId('cron'));
	}

	/**
	 * Runs on deactivation of the plugin.
	 *
	 * @return void.
	 */
	public static function deActivation() {
		wp_clear_scheduled_hook(self::buildFieldId('cron'));
	}

	/**
	 * The cron job.
	 *
	 * @return void.
	 */
	public function cron() {
		$allAuthorities = get_posts(array(
			'post_type' => self::buildFieldId(PsiCompliantAuthorityPostType::POST_TYPE),
			'post_status' => 'any',
			'posts_per_page' => '-1',
			'orderby' => 'title',
			'order'=> 'ASC',
		));

		$offset = (get_transient(self::buildFieldId('cron_offset')) ? get_transient(self::buildFieldId('cron_offset')) : 0);

		if($offset >= count($allAuthorities)) {
			$offset = 0;
		}

		$authorities = get_posts(array(
			'post_type' => self::buildFieldId(PsiCompliantAuthorityPostType::POST_TYPE),
			'post_status' => 'any',
			'posts_per_page' => self::CRON_PER_PAGE,
			'offset' => $offset,
			'orderby' => 'date',
			'order'=> 'ASC',
		));

		foreach($authorities as $key => $authority) {
			set_time_limit(30);

			$offset++;
			set_transient(self::buildFieldId('cron_offset'), $offset, 12 * HOUR_IN_SECONDS);

			$previousStatus = PsiCompliantAuthorityPostType::getAuthorityStatus($authority->ID);
			$checksSinceApproved = intval(get_post_meta($authority->ID, PsiComplianceMonitor::buildFieldId('checks_since_approved'), true));

			$p = new PsiCronChecker($authority->ID);

			$currentStatus = PsiCompliantAuthorityPostType::getAuthorityStatus($authority->ID, true);

			if($previousStatus == PsiCompliantAuthorityPostType::AUTHORITY_STATUS_APPROVED && $currentStatus == PsiCompliantAuthorityPostType::AUTHORITY_STATUS_APPROVED) {
				update_post_meta($authority->ID, PsiComplianceMonitor::buildFieldId('checks_since_approved'), 0);
			} else {
				update_post_meta($authority->ID, PsiComplianceMonitor::buildFieldId('checks_since_approved'), $checksSinceApproved+1);
			}
		}
	}

	/**
	 * Builds a field id based on the domain prefix to use in markup and database.
	 *
	 * @param string $fieldName The name of the field.
	 * 
	 * @return string Returns a field name based on the domain prefix.
	 */
	public static function buildFieldId($fieldName) {
		return self::DOMAIN . '_' . $fieldName; 
	}

	/**
	 * Renders a template from PsiComplianceMonitor/snippets
	 *
	 * @param string $path The path to the template without ".html.php".
	 * @param array $args Template data.
	 * @param boolean $echo If the output should be echoed out instead of being returned.
	 *
	 * @return void.
	 */
	public static function renderTemplate($path, array $args = array(), $echo = true) {
		if (!$path) {
			throw new \InvalidArgumentException('Invalid template name');
		}

		ob_start();

		$templateData = !empty($args) ? (object)$args : (object)array();
		require(self::$pluginPath . '/snippets/' . $path . '.html.php');

		$contents = ob_get_contents();
		ob_end_clean();

		if ($echo) {
			echo $contents;
		} else {
			return $contents;
		}
	}

	/**
	 * Checks if a metatag exists for a post.
	 *
	 * @param int $postId The post id.
	 * @param string $metaKey The key for the meta data.
	 *
	 * @return boolean True if exists.
	 */
	public static function postMetaExists($postId, $metaKey) {
		$metaData = get_post_custom($postId);

		if(isset($metaData[$metaKey])) {
			return true;
		}

		return false;
	}

	/**
	 * Get all authority posts (posts with custom post type PsiCompliantAuthorityPostType).
	 *
	 * @return array List of post objects.
	 */
	public function getAllAuthorities() {
		$authorities = get_posts(array(
			'post_type' => PsiComplianceMonitor::buildFieldId(PsiCompliantAuthorityPostType::POST_TYPE),
			'post_status' => 'any',
			'posts_per_page' => '-1',
			'orderby' => 'title',
			'order'=> 'ASC',
		));

		return $authorities;
	}

	/**
	 * Filter list of authorities by the status an authority post has.
	 *
	 * @param array $authorities The list of authority posts to filter.
	 * @param int $status The status code (See AUTHORITY_STATUS_FAILED|AUTHORITY_STATUS_WAITING|AUTHORITY_STATUS_APPROVED).
	 *
	 * @return void.
	 */
	public function filterAuthoritiesByStatus(&$authorities, $status) {
		$approved = array();

		foreach($authorities as $authority) {
			if(PsiCompliantAuthorityPostType::getAuthorityStatus($authority->ID) == $status) {
				$approved[] = $authority;
			}
		}

		$authorities = $approved;
	}

	/**
	 * Converts authority posts to stcClass array to use as json result.
	 *
	 * @param array $authorities The list of authority posts to convert.
	 *
	 * @return void.
	 */
	public function convertAuthoritiesToCustomArray(&$authorities) {
		$stdClsArray = array();
			
		foreach($authorities as $value) {
			$authority = new stdClass();
			$suffix = get_post_meta($value->ID, PsiComplianceMonitor::buildFieldId('api_suffix'), true);
			$authority->url = get_post_meta($value->ID, PsiComplianceMonitor::buildFieldId('url'), true) . ($suffix == null ? '' : '/' . $suffix);
			$authority->name = $value->post_title;
			$authority->email = get_post_meta($value->ID, PsiComplianceMonitor::buildFieldId('contact_email'), true);
			$authority->date = get_post_meta($value->ID, PsiComplianceMonitor::buildFieldId('checked_date'), true);
			
			$stdClsArray[] = $authority;
		}

		$authorities = $stdClsArray;
	}

	/**
	 * Adds a wrapper object to authority list.
	 *
	 * @param array $authorities The list of authority posts to convert.
	 *
	 * @return stdClass A stdClass with properties for count and items (data).
	 */
	public function addItemsToWrapperObject($authorities) {
		$wrapper = new APIWrapper(false);
		$wrapper->items = $authorities;
		$wrapper->count = count($authorities);
		$wrapper->message = 'ok';
		$wrapper->succeeded = true;

		return $wrapper;
	}
}