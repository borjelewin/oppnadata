<?php

class StatusCodeFilter {

	private $postType = '';

	/**
	 * Sets up the object.
	 *
	 * @param string $postType The post type for the filter.
	 * @param string $taxonomy The taxonomy name that you want to be able to filter.
	 *
	 * @return void.
	 */
	public function __construct($postType) {
		$this->postType = $postType;

		add_action('parse_query',array(&$this, 'parseQuery'));
		add_action('restrict_manage_posts', array(&$this, 'outputSelect'));

	}

	/**
	 * Outputs the select-field for the status filter.
	 *
	 * @return void.
	 */
	public function outputSelect() {
		global $wpdb, $pagenow, $typenow;

		if (!is_admin() || $pagenow != 'edit.php' || $typenow != $this->postType) {
			return;
		}

		$sql = "SELECT DISTINCT meta_value FROM " . $wpdb->postmeta . " WHERE meta_key = '" . PsiComplianceMonitor::buildFieldId('status_key') . "'";
		$values = $wpdb->get_results($sql, ARRAY_N);
		$current = isset($_GET[PsiComplianceMonitor::buildFieldId('status_key')])? $_GET[PsiComplianceMonitor::buildFieldId('status_key')] : '';
		
		PsiComplianceMonitor::renderTemplate(
			'statusCodeFilter', 
			array(
				'values' => $values,
				'current' => $current
			), 
			true
		);
	}
	
	/**
	 * Adds the meta data as filter to the main query.
	 *
	 * @param string $query The main query.
	 *
	 * @return void.
	 */
	public function parseQuery($query) {
		global $pagenow, $typenow;

		if (!is_admin() || $pagenow != 'edit.php' || $typenow != $this->postType || !isset($_GET[PsiComplianceMonitor::buildFieldId('status_key')]) ||  $_GET[PsiComplianceMonitor::buildFieldId('status_key')] == '') {
			return;
		}

		$query->query_vars['meta_key'] = PsiComplianceMonitor::buildFieldId('status_key');
		$query->query_vars['meta_value'] = $_GET[PsiComplianceMonitor::buildFieldId('status_key')];
	}

}