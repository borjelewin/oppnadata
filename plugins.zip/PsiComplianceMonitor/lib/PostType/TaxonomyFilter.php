<?php

class TaxonomyFilter {

	private $postType = '';
	private $taxonomy = '';

	/**
	 * Sets up the object.
	 *
	 * @param string $postType The post type for the filter.
	 * @param string $taxonomy The taxonomy name that you want to be able to filter.
	 *
	 * @return void.
	 */
	public function __construct($postType, $taxonomy) {
		$this->postType = $postType;
		$this->taxonomy = $taxonomy;

		add_action('restrict_manage_posts', array(&$this, 'restrictPostByTaxonomy'));
		add_filter('parse_query', array(&$this, 'convertIdToTermInQuery'));
	}

	/**
	 * Adds the dropdown filter to the posts overview page.
	 *
	 * @return void.
	 */
	function restrictPostByTaxonomy() {
		global $typenow;

		$postType = $this->postType;
		$taxonomy = $this->taxonomy;

		if ($typenow == $postType) {
			$selected = isset($_GET[$taxonomy]) ? $_GET[$taxonomy] : '';
			$infoTaxonomy = get_taxonomy($taxonomy);

			wp_dropdown_categories(array(
				'show_option_all' => __('Visa alla ' . strtolower($infoTaxonomy->label), PsiComplianceMonitor::DOMAIN),
				'taxonomy' => $taxonomy,
				'name' => $taxonomy,
				'orderby' => 'name',
				'selected' => $selected,
				'show_count' => true,
				'hide_empty' => false,
			));
		};
	}


	/**
	 * Changes the query for the posts overview page.
	 *
	 * @param string $query The main query.
	 *
	 * @return void.
	 */
	function convertIdToTermInQuery($query) {
		global $pagenow;

		$postType = $this->postType;
		$taxonomy = $this->taxonomy;

		$q_vars = &$query->query_vars;

		if ($pagenow == 'edit.php' && isset($q_vars['post_type']) && $q_vars['post_type'] == $postType && isset($q_vars[$taxonomy]) && is_numeric($q_vars[$taxonomy]) && $q_vars[$taxonomy] != 0) {
			$term = get_term_by('id', $q_vars[$taxonomy], $taxonomy);
			$q_vars[$taxonomy] = $term->slug;
		}
	}

}