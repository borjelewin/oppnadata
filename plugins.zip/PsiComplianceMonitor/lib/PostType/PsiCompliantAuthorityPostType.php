<?php

class PsiCompliantAuthorityPostType {
	const POST_TYPE = 'authority';
	const API_SUFFIX = 'psidata';

	const AUTHORITY_STATUS_FAILED = 1;
	const AUTHORITY_STATUS_WAITING = 2;
	const AUTHORITY_STATUS_APPROVED = 4;

	private $statusCodesTaxonomy;

	/**
	 * Sets up the custom post type.
	 */
	public function __construct() {
		new TaxonomyFilter(PsiComplianceMonitor::buildFieldId(self::POST_TYPE), PsiComplianceMonitor::buildFieldId('response'));

		add_action('init', array( &$this, 'registerTaxonomies'));
		add_action('after_setup_theme', array(&$this, 'registerPostType'));

		add_filter('manage_edit-' . PsiComplianceMonitor::buildFieldId(self::POST_TYPE) . '_columns', array(&$this, 'addColumns'));
		add_action('manage_' . PsiComplianceMonitor::buildFieldId(self::POST_TYPE) . '_posts_custom_column', array(&$this, 'manageColumns'), 10, 2);

		add_action( 'save_post', array( &$this, 'savePost' ) );
		add_action( 'delete_post', array( &$this, 'deletePost' ) );

		add_action('add_meta_boxes', array( &$this, 'addMetaData'));
		$this->statusCodesTaxonomy = new StatusCodesTaxonomy(PsiComplianceMonitor::buildFieldId(self::POST_TYPE), PsiComplianceMonitor::buildFieldId('response'));

		// Add status code filter.
		new StatusCodeFilter(PsiComplianceMonitor::buildFieldId(self::POST_TYPE));
	}

	/**
	 * Adds the metaboxes for the different meta data that should be saved
	 * with the authority.
	 *
	 * @return void.
	 */
	public function addMetaData(){
		global $pagenow;

		add_meta_box(
			PsiComplianceMonitor::buildFieldId('manually_approved'),
			__('Manuellt kontrollerad', PsiComplianceMonitor::DOMAIN),
			array(&$this, 'addMetaBox'),
			PsiComplianceMonitor::buildFieldId(self::POST_TYPE),
			'normal',
			'core',
			array('metaname' => 'manually_approved', 'template' => 'audit')
		);

		// Only add API URL box if we are editing a post.
		if($pagenow != 'post-new.php') {
			add_meta_box(
				PsiComplianceMonitor::buildFieldId('api_url'),
				__('API URL', PsiComplianceMonitor::DOMAIN),
				array(&$this, 'addMetaBox'),
				PsiComplianceMonitor::buildFieldId(self::POST_TYPE),
				'normal',
				'core',
				array('metaname' => 'url', 'template' => 'apiLink', 'description' => __('Den kompletta länken som kontrolleras.', PsiComplianceMonitor::DOMAIN))
			);
		}

		add_meta_box(
			PsiComplianceMonitor::buildFieldId('url'),
			__('URL (domän)', PsiComplianceMonitor::DOMAIN),
			array(&$this, 'addMetaBox'),
			PsiComplianceMonitor::buildFieldId(self::POST_TYPE),
			'normal',
			'core',
			array('metaname' => 'url', 'template' => 'input', 'description' => __('Kom ihåg att lägga till http:// samt att avsluta en länk med ett "/" (http://api.exempel.se/)', PsiComplianceMonitor::DOMAIN))
		);

		add_meta_box(
			PsiComplianceMonitor::buildFieldId('api_suffix'),
			__('API suffix (sökväg)', PsiComplianceMonitor::DOMAIN),
			array(&$this, 'addMetaBox'),
			PsiComplianceMonitor::buildFieldId(self::POST_TYPE),
			'normal',
			'core',
			array('metaname' => 'api_suffix', 'template' => 'input', 'default' => self::API_SUFFIX, 'description' => __('Sträng som läggs till efter URL:en (http://www.exempel.se/psidata)', PsiComplianceMonitor::DOMAIN))
		);

		add_meta_box(
			PsiComplianceMonitor::buildFieldId('contact_name'),
			__('Kontaktperson namn', PsiComplianceMonitor::DOMAIN),
			array(&$this, 'addMetaBox'),
			PsiComplianceMonitor::buildFieldId(self::POST_TYPE),
			'normal',
			'core',
			array('metaname' => 'contact_name', 'template' => 'input')
		);

		add_meta_box(
			PsiComplianceMonitor::buildFieldId('contact_email'),
			__('Kontaktperson epost', PsiComplianceMonitor::DOMAIN),
			array(&$this, 'addMetaBox'),
			PsiComplianceMonitor::buildFieldId(self::POST_TYPE),
			'normal',
			'core',
			array('metaname' => 'contact_email', 'template' => 'input')
		);
	}

	/**
	 * Adds the metaboxes for the different meta data that should be saved
	 * with the authority.
	 *
	 * @param int $postId The post id.
	 *
	 * @return void.
	 */
	public function savePost($postId){
		global $pagenow;

		if(defined('DOING_AUTOSAVE') && DOING_AUTOSAVE){
			return $postId;
		}

		if( 'page' == $_POST['post_type'] ) {
			if( !current_user_can('edit_page', $postId)){
				return $postId;
			}
		}else{
			if(!current_user_can('edit_post', $postId)){
				return $postId;
			}
		}

		// Don't update post meta if bulk edit.
		if($pagenow == 'edit.php') {
			return $postId;
		}
		if(isset($_REQUEST['bulk_edit'])) {
			return $postId;
		}

		// checkbox
		update_post_meta(
			$postId, 
			PsiComplianceMonitor::buildFieldId('manually_approved'), 
			(isset($_POST[PsiComplianceMonitor::buildFieldId('manually_approved')]) ? 1 : 0)
		);
		update_post_meta(
			$postId, 
			PsiComplianceMonitor::buildFieldId('manually_failed'), 
			(isset($_POST[PsiComplianceMonitor::buildFieldId('manually_failed')]) ? 1 : 0)
		);

		// input fields
		if(isset($_POST[PsiComplianceMonitor::buildFieldId('url')])) {
			update_post_meta($postId, PsiComplianceMonitor::buildFieldId('url'), trim($_POST[PsiComplianceMonitor::buildFieldId('url')]));
		}
		if(isset($_POST[PsiComplianceMonitor::buildFieldId('api_suffix')])) {
			update_post_meta($postId, PsiComplianceMonitor::buildFieldId('api_suffix'), trim($_POST[PsiComplianceMonitor::buildFieldId('api_suffix')]));
		}
		if(isset($_POST[PsiComplianceMonitor::buildFieldId('contact_name')])) {
			update_post_meta($postId, PsiComplianceMonitor::buildFieldId('contact_name'), $_POST[PsiComplianceMonitor::buildFieldId('contact_name')]);
		}
		if(isset($_POST[PsiComplianceMonitor::buildFieldId('contact_email')])) {
			update_post_meta($postId, PsiComplianceMonitor::buildFieldId('contact_email'), $_POST[PsiComplianceMonitor::buildFieldId('contact_email')]);
		}

		// Update status for filtering.
		self::updateAuthorityStatus($postId);
	}

	/**
	 * Removes meta data that is connected with the post.
	 *
	 * @param int $postId The post id.
	 *
	 * @return void.
	 */
	public function deletePost($postId){
		delete_post_meta($postId, PsiComplianceMonitor::buildFieldId('manually_approved'));
		delete_post_meta($postId, PsiComplianceMonitor::buildFieldId('manually_failed'));
		delete_post_meta($postId, PsiComplianceMonitor::buildFieldId('url'));
		delete_post_meta($postId, PsiComplianceMonitor::buildFieldId('api_suffix'));
		delete_post_meta($postId, PsiComplianceMonitor::buildFieldId('contact_name'));
		delete_post_meta($postId, PsiComplianceMonitor::buildFieldId('contact_email'));
		delete_post_meta($postId, PsiComplianceMonitor::buildFieldId('checked_date'));
		delete_post_meta($postId, PsiComplianceMonitor::buildFieldId('status_key'));
	}

	/**
	 * Adds a meta box to the admin interface for the post type.
	 *
	 * @param Object $post The post object.
	 * @param Array $params An array containing all the arguments
	 *
	 * @return void.
	 */
	public function addMetaBox($post, $params) {
		$template = (isset($params['args']['template']) ? $params['args']['template'] : '');
		$metaname = (isset($params['args']['metaname']) ? $params['args']['metaname'] : '');
		$defaultValue = (isset($params['args']['default']) ? $params['args']['default'] : '');
		$description = (isset($params['args']['description']) ? $params['args']['description'] : '');
		$label = (isset($params['args']['label']) ? $params['args']['label'] : '');

		if((!isset($template) || $template == '') || (!isset($metaname) || $metaname == '')) {
			throw new \InvalidArgumentException('No template given');
		}

		$data = $defaultValue;

		if(PsiComplianceMonitor::postMetaExists($post->ID, PsiComplianceMonitor::buildFieldId($metaname))) {
			$data = get_post_meta($post->ID, PsiComplianceMonitor::buildFieldId($metaname), true);
		}

		PsiComplianceMonitor::renderTemplate(
			'metaboxes/' . $template, 
			array(
				'id' => PsiComplianceMonitor::buildFieldId($metaname),
				'name' => PsiComplianceMonitor::buildFieldId($metaname),
				'value' => $data,
				'description' => $description,
				'label' => $label,
				'postid' => $post->ID
			), 
			true
		);
	}

	/**
	 * Registers the needed taxonomies.
	 *
	 * @return void.
	 */
	public function registerTaxonomies() {
		register_taxonomy(  
			PsiComplianceMonitor::buildFieldId('response'),  
			PsiComplianceMonitor::buildFieldId(self::POST_TYPE),  
			array(  
				'hierarchical' => true,  
				'label' => __('Statuskoder', PsiComplianceMonitor::DOMAIN),  
				'query_var' => true,
				'show_tagcloud' => false,
				'rewrite' => array('slug' => 'psi-response')  
			)  
		);
		$this->statusCodesTaxonomy->addCategories();

		register_taxonomy(  
			PsiComplianceMonitor::buildFieldId('format'),  
			PsiComplianceMonitor::buildFieldId(self::POST_TYPE),  
			array(  
				'hierarchical' => true,  
				'label' => __('Datatypsstöd', PsiComplianceMonitor::DOMAIN),  
				'query_var' => true,  
				'rewrite' => array('slug' => 'psi-format')  
			)  
		);

		register_taxonomy(  
			PsiComplianceMonitor::buildFieldId('quality'),  
			PsiComplianceMonitor::buildFieldId(self::POST_TYPE),  
			array(  
				'hierarchical' => true,  
				'label' => __('Datakvalitet', PsiComplianceMonitor::DOMAIN),  
				'query_var' => true,  
				'rewrite' => array('slug' => 'psi-quality')  
			)  
		);

		$this->registerTaxonomiesTerms();
	}

	/**
	 * Adds new columns to the post overview page.
	 *
	 * @param array $columns An array with the columns.
	 * 
	 * @return array An array with the columns.
	 */
	function addColumns($columns) {
		$columns['status_code'] = __('Status kod');
		$columns['status'] = __('Status');
		return $columns;
	}

	/**
	 * Writes out the content for custom columns.
	 *
	 * @param string $columnName The column name.
	 * @param int $id The post id.
	 * 
	 * @return void.
	 */
	function manageColumns($columnName, $id) {
		global $wpdb;
		switch ($columnName) {
			case 'status_code':
				$termObjects = wp_get_post_terms($id, PsiComplianceMonitor::buildFieldId('response'));
				$terms = array();
				foreach($termObjects as $term) {
					$terms[] = esc_html($term->name);
				}
				echo implode(', ', $terms);
			break;
			case 'status':
				echo PsiCompliantAuthorityPostType::authorityStatusCodeToString(PsiCompliantAuthorityPostType::getAuthorityStatus($id));
			break;
		}
	}  

	/**
	 * Registers predefined terms for taxonomies.
	 *
	 * @return void.
	 */
	private function registerTaxonomiesTerms() {
		wp_insert_term(
			'XML',
			PsiComplianceMonitor::buildFieldId('format'),
			array(
				'description'=> __('Datauppsättningen är i XML format', PsiComplianceMonitor::DOMAIN),
				'slug' => 'format-xml',
			)
		);
		wp_insert_term(
			'JSON',
			PsiComplianceMonitor::buildFieldId('format'),
			array(
				'description'=> __('Datauppsättningen är i JSON format', PsiComplianceMonitor::DOMAIN),
				'slug' => 'format-json',
			)
		);
		wp_insert_term(
			'HTML',
			PsiComplianceMonitor::buildFieldId('format'),
			array(
				'description'=> __('Datauppsättningen är i HTML format', PsiComplianceMonitor::DOMAIN),
				'slug' => 'format-html',
			)
		);
		wp_insert_term(
			'PDF',
			PsiComplianceMonitor::buildFieldId('format'),
			array(
				'description'=> __('Datauppsättningen är i PDF format', PsiComplianceMonitor::DOMAIN),
				'slug' => 'format-pdf',
			)
		);
	}

	/**
	 * Saves the authority status as a meta value (used only for filtering in admin, may be out of sync!).
	 *
	 * @param int $postId The id of the post you want to update.
	 *
	 * @return void.
	 */
	public static function updateAuthorityStatus($postId) {
		$status = self::getAuthorityStatus($postId);
		update_post_meta($postId, PsiComplianceMonitor::buildFieldId('status_key'), $status);
	}

	/**
	 * Checks what status an authority post has.
	 *
	 * @param int     $postId The id of the post you want to check.
	 * @param boolean $strict [Optional] If we should do a strict check.
	 *
	 * @return int The status code (See AUTHORITY_STATUS_FAILED|AUTHORITY_STATUS_WAITING|AUTHORITY_STATUS_APPROVED).
	 */
	public static function getAuthorityStatus($postId, $strict = false) {
		if(is_null(get_post($postId))) {
			throw new \InvalidArgumentException('Invalid post id supplied: '.$postId);
		}

		// Check status code
		$statusCodeApproved = false;
		$checksSinceApproved = intval(get_post_meta($postId, PsiComplianceMonitor::buildFieldId('checks_since_approved'), true));

		if(has_term(array('http-code-200', 'http-code-302', 'http-code-301'), PsiComplianceMonitor::buildFieldId('response'), $postId)) {
			$statusCodeApproved = true;
		}

		// Check manual approvement
		$manuallyApproved = get_post_meta($postId, PsiComplianceMonitor::buildFieldId('manually_approved'), true);
		$manuallyFailed = get_post_meta($postId, PsiComplianceMonitor::buildFieldId('manually_failed'), true);

		// Determine status

		if($manuallyFailed) {
			return self::AUTHORITY_STATUS_FAILED;
		}

		if($statusCodeApproved && $manuallyApproved) {
			return self::AUTHORITY_STATUS_APPROVED;
		}

		if(($manuallyApproved && $checksSinceApproved <= 3) && $strict == false) {
			return self::AUTHORITY_STATUS_APPROVED;
		}

		if($statusCodeApproved || $manuallyApproved) {
			return self::AUTHORITY_STATUS_WAITING;
		}

		return self::AUTHORITY_STATUS_FAILED;
	}

	/**
	 * Returns the string equivalent of the AUTHORITY_STATUS_ constants.
	 *
	 * @param int $status The status code.
	 *
	 * @return String.
	 */
	public static function authorityStatusCodeToString($status) {
		switch(intval($status)) {
			case 1:
				return __('Ej godkänd', PsiComplianceMonitor::DOMAIN);
			break;

			case 2:
				return __('Granskas', PsiComplianceMonitor::DOMAIN);
			break;

			case 4:
				return __('Godkänd', PsiComplianceMonitor::DOMAIN);
			break;

			case 0:
			default:
				return __('Okänd status', PsiComplianceMonitor::DOMAIN);
			break;
		}
	}

	/**
	 * Registers the custom post type.
	 *
	 * @return void.
	 */
	public function registerPostType(){

		register_post_type( 
			PsiComplianceMonitor::buildFieldId(self::POST_TYPE),
			array(
				'labels' => array(
					'name' => __('PSI myndigheter', PsiComplianceMonitor::DOMAIN),
					'singular_name' => __( 'PSI myndighet', PsiComplianceMonitor::DOMAIN),
					'add_new' => __('Skapa ny PSI myndighet', PsiComplianceMonitor::DOMAIN),
					'add_new_item' => __('Skapa ny PSI myndighet', PsiComplianceMonitor::DOMAIN),
					'edit_item' => __('Editera PSI myndighet', PsiComplianceMonitor::DOMAIN)
				),
				'public' => true,
				'show_ui' => true,
				'capability_type' => 'post',
				'hierarchical' => false,
				'rewrite' => array('slug' => 'psi-site'),
				'query_var' => true,
				'supports' => array( 'title', 'editor', 'categories' )
			)
		 );
	}

}