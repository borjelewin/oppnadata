<?php

class StatusCodesTaxonomy {
	private $taxonomy;

	/**
	 * Sets up the status code taxonomy.
	 */
	public function __construct($posttype, $taxonomy) {
		$this->posttype = $posttype;
		$this->taxonomy = $taxonomy;

		add_action('admin_menu',  array(&$this, 'removeFromAdminMenu'), 999);
		add_action('admin_menu', array(&$this, 'removeCategoryMetaBox'));
		add_action('add_meta_boxes', array(&$this, 'addCustomMetaBoxes'));
	}

	/**
	 * Removes the link to edit the taxonomy in admin from the sub menu.
	 *
	 * @return void.
	 */
	public function removeFromAdminMenu() {
		global $submenu;

		remove_submenu_page(
			'edit.php?post_type=' . $this->posttype, 
			'edit-tags.php?taxonomy=' . $this->taxonomy . '&amp;post_type=' . $this->posttype
		);
	}

	/**
	 * Adds the default taxonomy terms.
	 *
	 * @return void.
	 */
	public function addCategories() {
		wp_insert_term(
			'HTTP 200',
			$this->taxonomy,
			array(
				'description'=> __('PSI förfrågan svarade med 200 OK', PsiComplianceMonitor::DOMAIN),
				'slug' => 'http-code-200',
			)
		);
		wp_insert_term(
			'HTTP 301',
			$this->taxonomy,
			array(
				'description'=> __('PSI förfrågan svarade med 301 MOVED PERMANENTLY', PsiComplianceMonitor::DOMAIN),
				'slug' => 'http-code-301',
			)
		);
		wp_insert_term(
			'HTTP 302',
			$this->taxonomy,
			array(
				'description'=> __('PSI förfrågan svarade med 302 FOUND', PsiComplianceMonitor::DOMAIN),
				'slug' => 'http-code-302',
			)
		);
		wp_insert_term(
			'HTTP 403',
			$this->taxonomy,
			array(
				'description'=> __('PSI förfrågan svarade med 403 FORBIDDEN', PsiComplianceMonitor::DOMAIN),
				'slug' => 'http-code-403',
			)
		);
		wp_insert_term(
			'HTTP 404',
			$this->taxonomy,
			array(
				'description'=> __('PSI förfrågan svarade med 404 NOT FOUND', PsiComplianceMonitor::DOMAIN),
				'slug' => 'http-code-404',
			)
		);
		wp_insert_term(
			'HTTP 500',
			$this->taxonomy,
			array(
				'description'=> __('PSI förfrågan svarade med 500 INTERNAL SERVER ERROR', PsiComplianceMonitor::DOMAIN),
				'slug' => 'http-code-500',
			)
		);
		wp_insert_term(
			'HTTP 503',
			$this->taxonomy,
			array(
				'description'=> __('PSI förfrågan svarade med 503 SERVICE UNAVAILABLE', PsiComplianceMonitor::DOMAIN),
				'slug' => 'http-code-503',
			)
		);
		wp_insert_term(
			'Annan kod',
			$this->taxonomy,
			array(
				'description'=> __('PSI förfrågan svarade med en annan kod', PsiComplianceMonitor::DOMAIN),
				'slug' => 'http-code-other',
			)
		);
	}
 
 	/**
	 * Removes the default taxonomy meta box in admin.
	 *
	 * @return void.
	 */
	public function removeCategoryMetaBox(){
		remove_meta_box($this->taxonomy.'div', $this->posttype, 'normal');
	}

	/**
	 * Adds the custom meta box to the admin interface.
	 *
	 * @return void.
	 */
	public function addCustomMetaBoxes() {
		add_meta_box(
			'psi-response-custom-div', 
			__('PSI respons', PsiComplianceMonitor::DOMAIN),
			array(
				&$this, 
				'renderRadioMetaBox'
			), 
			$this->posttype,
			'side',
			'core',
			array(
				'taxonomy' => $this->taxonomy
			)
		);
	}

	/**
	 * Renders the custom meta box from template.
	 *
	 * @param Object $post The post object.
	 * @param Array $params The parameters sent in.
	 *
	 * @return void.
	 */
	public function renderRadioMetaBox($post, $params) {
		if(isset($params['args'])) {
			extract($params['args']);
		}

		$tax = get_taxonomy($taxonomy);
		$terms = get_terms($taxonomy,array('hide_empty' => 0));

		$name = 'tax_input[' . $taxonomy . ']';

		$postterms = get_the_terms($post->ID, $taxonomy);
		$current = ($postterms ? array_pop($postterms) : false);
		$current = ($current ? $current->term_id : 0);
		$checkedDate = get_post_meta($post->ID, PsiComplianceMonitor::buildFieldId('checked_date'), true);

		PsiComplianceMonitor::renderTemplate(
			'metaboxes/radioTaxonomy', 
			array(
				'taxonomy' => $taxonomy,
				'terms' => $terms,
				'current' => $current,
				'name' => $name,
				'checkedDate' =>$checkedDate,
			), 
			true
		);
	}
}