<?php

/**
 * Represents an individual settings field.
 */
class WidgetField {
	/**
	 * The type of field.
	 * @var string
	 */
	public $type;

	/**
	 * The title of the field
	 * @var string
	 */
	public $title;

	/**
	 * If the content in the field is allowed to have html in it.
	 * @var boolean
	 */
	public $allowHtml;

	/**
	 * Optional help text.
	 * @var string
	 */
	public $help;

	/**
	 * Arbitary options (used for select options)
	 * @var mixed
	 */
	public $options;

	/**
	 * Default content.
	 * @var mixed
	 */
	public $default;

	/**
	 * Constructor.
	 *
	 * @return void
	 */
	function __construct($type, $title = '', $allowHtml = false, $help = '', $options = false) {
		$this->type = $type;
		$this->title = $title;
		$this->allowHtml = $allowHtml;
		$this->help = $help;
		$this->options = $options;
		$this->default = false;
	}
}