<?php

/**
 * A PSI widget
 */
class PsiWidget extends BaseWidget {


	/**
	 * Constructor.
	 *
	 * @return void
	 */
	public function __construct() {

		parent::__construct(
			PsiComplianceMonitor::buildFieldId('widget'), // Base ID
			'PSI widget', // Name
			array(
				'classname' => 'psi-widget',
				'description' => __('A psi widget', PsiComplianceMonitor::DOMAIN)
			)
		);


		// Create fields here.
		$this->fields['type'] = new WidgetField(
			'select',
			__('Typ', PsiComplianceMonitor::DOMAIN) . ':',
			false,
			__('Typ av myndigheter som ska visas', PsiComplianceMonitor::DOMAIN),
			array(
				'7' => 'All',
				'1' => 'Failed',
				'2' => 'Waiting',
				'4' => 'Approved'
			)
		);

		foreach ($this->fields as $key => $field) {
			$this->defaults[$key] = ($field->default ? $field->default: '');
		}

	}

	public static function render($status) {
		$allowedStatus = intval($status);
		$authorities = array();
		$allAuthorities = get_posts(array(
			'post_type' => PsiComplianceMonitor::buildFieldId(PsiCompliantAuthorityPostType::POST_TYPE),
			'post_status' => 'any',
			'posts_per_page' => '-1',
			'orderby' => 'title',
			'order'=> 'ASC',
		));

		foreach($allAuthorities as $authority) {
			$status = PsiCompliantAuthorityPostType::getAuthorityStatus($authority->ID);
			if($status & $allowedStatus) {
				$url = get_post_meta($authority->ID, PsiComplianceMonitor::buildFieldId('url'), true);
				$suffix = get_post_meta($authority->ID, PsiComplianceMonitor::buildFieldId('api_suffix'), true);
				
				$formats = array();
				$formatTerms = wp_get_post_terms($authority->ID, PsiComplianceMonitor::buildFieldId('format'));

				foreach($formatTerms as $term) {
					$formats[] = $term->name;
				}

				$authorities[] = (object) array(
					'id' => $authority->ID,
					'title' => get_the_title($authority->ID),
					'statusCode' => $status,
					'statusText' => PsiCompliantAuthorityPostType::authorityStatusCodeToString($status),
					'checkedDate' => get_post_meta($authority->ID, PsiComplianceMonitor::buildFieldId('checked_date'), true),
					'url' => PsiCronChecker::addTrailingSlash($url) . $suffix,
					'formats' => $formats,
				);
				
			}
		}

		return 	PsiComplianceMonitor::renderTemplate('widget/psiWidget', array('authorities' => $authorities), false);
	}

	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 */
	public function widget($args, $instance) {
		extract($args);

		// render widget
		echo $before_widget;
		echo self::render($instance['type']);
		echo $after_widget;
	}
}