<?php

/**
 * The base widget class.
 */
abstract class BaseWidget extends \WP_Widget {

	/**
	 * The default values.
	 * @var array
	 */
	private $defaults = array();

	/**
	 * Holds an array of fields.
	 * @var array That contains {@link Bazooka\WordPress\Widgets\WidgetField}.
	 */
	protected $fields = array();

	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	public function update($new_instance, $instance) {
		$new_instance = wp_parse_args((array) $new_instance, $this->defaults);

		foreach ($this->fields as $key => $field) {
			if (isset($field->allowHtml) && $field->allowHtml) {
				$instance[$key] = $new_instance[$key];
			} else {
				$instance[$key] = strip_tags($new_instance[$key]);
			}
		}

		return $instance;
	}

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
	public function form($instance) {
		$output = '';
		$instance = wp_parse_args((array) $instance, $this->defaults);

		foreach ($this->fields as $key => $field) {
			$data = '';

			if (isset($instance[$key])) {
				if (isset($field->allowHtml) && $field->allowHtml) {
					$data = $instance[$key];
				} else {
					$data = strip_tags($instance[$key]);
				}
			}

			$output .= '<p><label for="' . $this->get_field_id($key) . '">' . __($field->title) . '</label>';

			$methodName = 'renderForm' . ucfirst(strtolower($field->type));

			if (!method_exists($this, $methodName)) {
				$methodName = 'renderFormInput';
			}

			$output .= call_user_func(array($this, $methodName), $key, $field, $data);

			if (isset($field->help)) {
				$output .= '<span class="help">'. esc_html($field->help) . '</span>';
			}

			$output .= '</p>';
		}

		echo $output;
	}

	/**
	 * Renders a textarea input field.
	 *
	 * @param string $key The field key.
	 * @param object $field The field object.
	 * @param mixed $data The field data.
	 *
	 * @return string The rendered field.
	 */
	public function renderFormTextarea($key, $field, $data) {
		return '<textarea class="widefat" id="' . esc_attr($this->get_field_id($key)) . '" name="' . esc_attr($this->get_field_name($key)) . '">' . esc_html($data) . '</textarea>';
	}

	/**
	 * Renders a checkbox input field.
	 *
	 * @param string $key The field key.
	 * @param object $field The field object.
	 * @param mixed $data The field data.
	 *
	 * @return string The rendered field.
	 */
	public function renderFormCheckbox($key, $field, $data) {
		return '<input id="' . esc_attr($this->get_field_id($key)) . '" name="' . esc_attr($this->get_field_name($key)) . '" type="checkbox" value="' . esc_attr($value) . '"' . ($data == $value ? ' checked="checked"': '') . '>';
	}

	/**
	 * Renders a radio input field.
	 *
	 * @param string $key The field key.
	 * @param object $field The field object.
	 * @param mixed $data The field data.
	 *
	 * @return string The rendered field.
	 */
	public function renderFormRadio($key, $field, $data) {
		$html = '';

		foreach ($field->options as $value => $title) {
			$html .= '<input id="' . $this->get_field_id($key) . '" name="' . $this->get_field_name($key) . '" type="radio" value="' . esc_attr($value) . '"' . ($data == $value ? ' selected="selected"': '') . '>';
		}

		return $html;
	}

	/**
	 * Renders a select input field.
	 *
	 * @param string $key The field key.
	 * @param object $field The field object.
	 * @param mixed $data The field data.
	 *
	 * @return string The rendered field.
	 */
	public function renderFormSelect($key, $field, $data) {
		$options = array();

		foreach ($field->options as $value => $title) {
			array_push($options, '<option value="' . esc_attr($value) . '"' . ($data == $value ? ' selected="selected"': '') . '>' . $title . '</option>');
		}

		return '<select class="widefat" id="' . esc_attr($this->get_field_id($key)) . '" name="' . esc_attr($this->get_field_name($key)) . '">' . implode('', $options) . '</select>';
	}

	/**
	 * Renders a text input field.
	 *
	 * @param string $key The field key.
	 * @param object $field The field object.
	 * @param mixed $data The field data.
	 *
	 * @return string The rendered field.
	 */
	public function renderFormInput($key, $field, $data) {
		return '<input class="widefat" id="' . esc_attr($this->get_field_id($key)) . '" name="' . esc_attr($this->get_field_name($key)) . '" type="text" value="' . esc_attr($data) . '">';
	}

	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 */
	public function widget($args, $instance) {
		extract($args);

		echo $before_widget;

		if ($instance['title']) {
			echo $before_title . $instance['title'] . $after_title;
		}

		if ($instance['text']) {
			echo $instance['text'];
		}

		echo $after_widget;
	}

	/**
	 * Fetches the sidebar id that the current widget resides in.
	 *
	 * @return mixed The id if found, otherwise null.
	 */
	protected function fetchCurrentSidebarId() {
		$sidebarsWidgets = wp_get_sidebars_widgets();

		if (is_array($sidebarsWidgets)) {
			foreach ($sidebarsWidgets as $sidebar => $widgets) {
				if (in_array($this->id, $widgets)) {
					return $sidebar;
				}
			}
		}

		return null;
	}
}