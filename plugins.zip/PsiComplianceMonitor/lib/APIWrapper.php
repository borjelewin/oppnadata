<?php
class APIWrapper {
	const CACHE_KEY = 'ApprovedAuthorities';

	public $items;
	public $succeeded;
	public $count;

	function __construct($useCache) {
		$this->items = null;
		$this->count = 0;
		$this->succeeded = false;

		if($useCache) {
			$this->getFromCache();
		}
	}

	function validCache() {
		return $this->items != false && $this->items != null;
	}

	function getFromCache() {
		$this->items = json_decode(get_transient(APIWrapper::CACHE_KEY));
		$this->count = count($this->items);
		
		if($this->count > 0) {
			$this->succeeded = true;
			$this->message = 'ok';
		}	
	}
}