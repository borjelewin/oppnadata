<?php
/**
 * Renders the select field for the status code filter
 * @package WordPress
 *
 * Available args:
 *
 * $templateData->values
 * $templateData->current
 */
 ?>
<select name="<?php echo PsiComplianceMonitor::buildFieldId('status_key'); ?>">
	<option value=""><?php _e('Visa alla', PsiComplianceMonitor::DOMAIN); ?></option>
	<?php foreach ($templateData->values as $value): ?>
		<?php $statusCode = intval($value[0]); ?>
		<?php if ($statusCode != 0): ?>
			<option value="<?php echo $statusCode; ?>" <?php echo ($statusCode == $templateData->current ? ' selected="selected"' : ''); ?>><?php echo esc_html(PsiCompliantAuthorityPostType::authorityStatusCodeToString($statusCode)); ?></option>
		<?php endif; ?>
	<?php endforeach; ?>
	?>
</select>