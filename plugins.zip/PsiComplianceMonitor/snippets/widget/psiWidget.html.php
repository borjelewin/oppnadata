<?php
/**
 * Renders the PSI widget.
 * @package WordPress
 *
 * Available args:
 *
 * $templateData->authorities
 * $templateData->authorities[]->id
 * $templateData->authorities[]->title
 * $templateData->authorities[]->statusCode
 * $templateData->authorities[]->statusText
 * $templateData->authorities[]->checkedDate
 * $templateData->authorities[]->url
 * $templateData->authorities[]->formats
 * 
 */

?>
<table class="psi-authorities">
	<tr>
		<th class="status"></th>
		<th>Kommun/myndighet</th>
		<th class="status-text">Status</th>
		<th class="date-checked">Senaste kontrollerad</th>
	</tr>
<?php foreach($templateData->authorities as $authority): ?>
	<tr>
		<td class="status status-<?php echo esc_html($authority->statusCode); ?>"></td>
		<td><a href="<?php echo $authority->url; ?>"><?php echo $authority->title; ?></a></td>
		<td class="status-text"><?php echo esc_html($authority->statusText); ?></td>
		<td class="date-checked"><?php echo esc_html(date_format(new DateTime($authority->checkedDate), 'Y-m-d')); ?></td>
	</tr>
<?php endforeach; ?>
</table>