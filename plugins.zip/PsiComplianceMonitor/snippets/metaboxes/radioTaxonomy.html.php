<?php
/**
 * Renders the radio taxonomy meta box for StatusCodesTaxonomy.
 * @package WordPress
 *
 * Available args:
 *
 * $templateData->taxonomy
 * $templateData->terms
 * $templateData->current
 * $templateData->name
 * $templateData->checkedDate
 */
?>
<div id="taxonomy-<?php echo $templateData->taxonomy; ?>" class="categorydiv">
		<ul id="<?php echo $templateData->taxonomy; ?>checklist" class="list:<?php echo $templateData->taxonomy?> categorychecklist form-no-clear">
			<?php foreach($templateData->terms as $term): ?>
				<?php $id = $templateData->taxonomy.'-'.$term->term_id; ?>
				<li id="<?php echo $id; ?>">
					<label class="selectit">
						<input type="radio" disabled="disabled" id="in-<?php echo $id; ?>" <?php echo checked($templateData->current,$term->term_id,false)?>value="<?php echo $term->term_id; ?>" /><?php echo esc_html($term->name); ?><br />
					</label>
					<?php if($templateData->current == $term->term_id): ?>
					<input type="hidden" name="<?php echo esc_attr($templateData->name); ?>" value="<?php echo $term->term_id; ?>" />
					<?php endif; ?>
				</li>
			<?php endforeach; ?>
		</ul>
	<div class="checked_date" style="font-size:10px; font-style:italic;">
		<?php echo __('Senast kontrollerad: ', PsiComplianceMonitor::DOMAIN); ?>
		<?php if($templateData->checkedDate != ''): ?>
			<?php echo esc_html($templateData->checkedDate); ?>
		<?php else: ?>
			<?php echo __('aldrig', PsiComplianceMonitor::DOMAIN); ?>
		<?php endif; ?>
	</div>
</div>