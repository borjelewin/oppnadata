<?php
/**
 * Renders two checkboxes, one approved, and one failed
 * @package WordPress
 *
 * Available args:
 *
 * $templateData->id
 * $templateData->value
 * $templateData->name
 * $templateData->description
 * $templateData->label
 * $templateData->postid
 */

$approved = PsiComplianceMonitor::buildFieldId('manually_approved');
$approvedData = 0;
if(PsiComplianceMonitor::postMetaExists($templateData->postid, PsiComplianceMonitor::buildFieldId('manually_approved'))) {
	$approvedData = get_post_meta($templateData->postid, PsiComplianceMonitor::buildFieldId('manually_approved'), true);
}

$failed = PsiComplianceMonitor::buildFieldId('manually_failed');
$failedData = 0;
if(PsiComplianceMonitor::postMetaExists($templateData->postid, PsiComplianceMonitor::buildFieldId('manually_failed'))) {
	$failedData = get_post_meta($templateData->postid, PsiComplianceMonitor::buildFieldId('manually_failed'), true);
}
?>
<?php if($templateData->description != ''): ?>
<p class="howto">
	<?php echo esc_html($templateData->description); ?>
</p>
<?php endif; ?>
<dl>
	<dt><label for="<?php echo esc_attr($approved); ?>"><?php echo __('Godkänd'); ?>:</label></dt>
	<dd>
		<input type="checkbox" id="<?php echo esc_attr($approved); ?>" <?php checked($approvedData, 1); ?> name="<?php echo esc_attr($approved); ?>" value="1" />
	</dd>
	<dt><label for="<?php echo esc_attr($failed); ?>"><?php echo __('Ej godkänd'); ?>:</label></dt>
	<dd>
		<input type="checkbox" id="<?php echo esc_attr($failed); ?>" <?php checked($failedData, 1); ?> name="<?php echo esc_attr($failed); ?>" value="1" />
	</dd>
</dl>

