<?php
/**
 * Renders a checkbox for meta boxes in admin.
 * @package WordPress
 *
 * Available args:
 *
 * $templateData->id
 * $templateData->value
 * $templateData->name
 * $templateData->description
 * $templateData->label
 */

?>
<?php if($templateData->description != ''): ?>
<p class="howto">
	<?php echo esc_html($templateData->description); ?>
</p>
<?php endif; ?>
<input type="checkbox" id="<?php echo esc_attr($templateData->id); ?>" <?php checked($templateData->value, 1); ?> name="<?php echo esc_attr($templateData->name); ?>" value="1" />
