<?php
/**
 * Renders a preview of the link that will be PSI checked.
 * @package WordPress
 *
 * Available args:
 *
 * $templateData->id
 * $templateData->name
 * $templateData->value
 * $templateData->description
 * $templateData->label
 */
$url = '';
if(PsiComplianceMonitor::postMetaExists($templateData->postid, PsiComplianceMonitor::buildFieldId('url'))) {
	$url = get_post_meta($templateData->postid, PsiComplianceMonitor::buildFieldId('url'), true);
}

$suffix = '';
if(PsiComplianceMonitor::postMetaExists($templateData->postid, PsiComplianceMonitor::buildFieldId('api_suffix'))) {
	$suffix = get_post_meta($templateData->postid, PsiComplianceMonitor::buildFieldId('api_suffix'), true);
}

$url = PsiCronChecker::addTrailingSlash($url) . $suffix;
?>
<?php if($templateData->description != ''): ?>
<p class="howto">
	<?php echo esc_html($templateData->description); ?>
</p>
<?php endif; ?>
<?php if(!empty($url) || $url != ''): ?>
<a href="<?php echo esc_url($url); ?>" target="_blank"><?php echo esc_html($url); ?></a>
<?php else: ?>
	<span><?php _e('Finns ingen URL att bygga.'); ?></span>
<?php endif; ?>
