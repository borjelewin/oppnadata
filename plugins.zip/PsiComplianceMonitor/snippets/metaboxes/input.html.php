<?php
/**
 * Renders an input field for meta boxes in admin.
 * @package WordPress
 *
 * Available args:
 *
 * $templateData->id
 * $templateData->name
 * $templateData->value
 * $templateData->description
 * $templateData->label
 */
?>
<?php if($templateData->description != ''): ?>
<p class="howto">
	<?php echo esc_html($templateData->description); ?>
</p>
<?php endif; ?>
<input type="text" class="psi-input-field" id="<?php echo esc_attr($templateData->id); ?>" name="<?php echo esc_attr($templateData->name); ?>" value="<?php echo wp_specialchars($templateData->value); ?>" />